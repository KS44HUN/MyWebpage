/**
 * nav.js - marks the menu item of the section currently in view (aria-current).
 */
(function () {
  'use strict';

  const links = [...document.querySelectorAll('nav a')];
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const id = '#' + entry.target.id;
      links.forEach((link) => {
        if (link.getAttribute('href') === id) link.setAttribute('aria-current', 'true');
        else link.removeAttribute('aria-current');
      });
    });
  }, { rootMargin: '-45% 0px -50% 0px' });

  document.querySelectorAll('main,section[id]').forEach((section) => observer.observe(section));
})();
