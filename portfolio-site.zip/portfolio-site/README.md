# Személyes IT portfólió

Statikus, két nyelvű (HU/EN) portfólióoldal – build lépés és külső függőség nélkül.
Elég megnyitni az `index.html`-t a böngészőben (internet csak a Google Fonts betűtípushoz kell).

## Szerkezet

```
index.html            az oldal tartalma (magyarul)
css/                  stílusok, a betöltési sorrend az index.html-ben számít
  tokens.css          színek (világos/sötét téma)
  base.css            reset, tipográfia, akadálymentesítési segédek
  header.css          fejléc, menü, nyelv- és témaváltó
  buttons.css         gombok
  hero.css            nyitó rész (főcím)
  lanyard.css         nyakpánt + névjegykártya
  coins.css           dekor érmék
  bridge.css          „híd" rész, ívelt felirat, gyorslink kártyák
  sections.css        közös szekciós stílusok
  skills.css          technológiák, logócsempék, szintjelző
  about.css           Rólam bento + tanulási tábla
  certificates.css    tanúsítványok
  contact-footer.css  kapcsolat linkek, lábléc
  responsive.css      globális töréspontok, csökkentett mozgás
js/                   működés (sima scriptek, szerver nélkül is futnak)
  i18n-data.js        angol fordítások (itt kell új szöveget felvenni)
  i18n.js             nyelvváltás
  theme.js            világos/sötét téma
  nav.js              aktív menüpont görgetéskor
  skills.js           szintjelző a logócsempéken
  lanyard.js          a névjegykártya lengése görgetésre
  marquee.js          ívelt felirat mozgása görgetésre
  main.js             indítás (a többi script után fut)
assets/img/           technológia-logók és a nyakpánt fotója
```

## Gyakori módosítások

- **Név, város, számok, linkek:** `index.html`. A „Neved Itt", „Városod, HU", az `X` jelű számok,
  a `#` linkek és az `nev@example.com` helyőrzők.
- **Új vagy módosított szöveg angolul:** vedd fel `js/i18n-data.js`-ben:
  `"Magyar szöveg": "English text"` (a kulcs betűre pontosan egyezzen az `index.html`-ben lévővel).
- **Technológia szintje:** a csempék `.sr` szövegében és a `.lv` részben a szám/szint neve (index.html, „Amivel dolgozom").
- **Színek:** `css/tokens.css`.
- **Lengés erőssége:** `js/lanyard.js` (`kick(...)` és a rugóállandók).

## Közzététel

A mappa statikus tárhelyre másolható (GitHub Pages, Netlify, Cloudflare Pages stb.).
Helyi szerverrel is indítható: `python3 -m http.server` a mappában.

## Megjegyzés

A scripteket szándékosan nem ES-modulként írtam, hogy az `index.html` dupla kattintásra (file://) is működjön.
